# Coverage Report (measured)

`make coverage` — GCC 13.3, `-O0 --coverage`, gcov; all three test binaries executed. Counts are of `src/*.c` only.
Branch % = gcov "Taken at least once".

| File | Lines % | Branch % | Function % |
|---|---|---|---|
| src/common.c | 100.00 | 100.00 | 100.0 (1/1) |
| src/bst.c | 97.83 | 92.86 | 100.0 (9/9) |
| src/station.c | 98.80 | 93.33 | 100.0 (7/7) |
| src/packet.c | 100.00 | 93.75 | 100.0 (9/9) |
| src/sliding_window.c | 96.00 | 85.65 | 100.0 (21/21) |
| src/storage.c | 91.67 | 88.46 | 100.0 (5/5) |
| src/input.c | 100.00 | 84.38 | 100.0 (4/4) |
| **TOTAL** | **96.9** | **88.9** | **100.0** |

`src/main.c` (interactive menu) is excluded: it is exercised manually, not by the unit tests.
Uncovered lines are mostly defensive paths (e.g. `malloc` failure, `fclose` failure, internal-state guards)
that cannot be triggered without fault injection.

Reproduce: `make coverage`. For an annotated view: `gcov -b -o build/cov src/bst.c` then open `bst.c.gcov`.
