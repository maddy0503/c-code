# 5G Telecom Reliable Packet Transmission Engine — Sliding Window (Go-Back-N) in C

A **software simulation** of reliable packet delivery inspired by telecom networks, plus a
**BST-based station manager**. It is *not* a 5G physical layer, radio stack or production protocol.

## 1. Objectives
* Reliable, ordered delivery over a lossy simulated channel (Go-Back-N ARQ).
* Station records stored in a Binary Search Tree keyed by Station ID.
* Secure input / memory handling, unit + functional tests, static analysis and coverage support.

## 2. Architecture
| Module | Responsibility |
|---|---|
| `common.[ch]` | shared `status_t` codes + messages |
| `station.[ch]` | station record, field validation, source/destination validation |
| `bst.[ch]` | iterative BST: insert/search/update/delete/inorder/preorder/stats/destroy |
| `packet.[ch]` | packet & ACK structs, sequence arithmetic (mod 16), circular channel queues |
| `sliding_window.[ch]` | Go-Back-N sender, receiver, timeout/retransmit, tick-based simulation, stats |
| `storage.[ch]` | validated save/load (all-or-nothing load, temp-file save) |
| `input.[ch]` | bounded `fgets` input, strict numeric parsing, retry prompts |
| `main.c` | 12-option menu |

## 3. Go-Back-N (vs Selective Repeat)
* Sender may have up to **N unacknowledged packets** in flight (flow control). Sequence numbers are 4-bit
  (0..15, wrap-around); max window = 15 (= modulus − 1).
* Receiver window is **1**: it accepts only the next expected sequence number. Anything else
  (duplicate or out-of-order) is **discarded** and answered with the same cumulative ACK.
* ACK = "next sequence expected" (cumulative). It advances the sender window by
  `distance(base, ack)` — duplicate/stale ACKs are ignored.
* One timer guards the oldest unacked packet. On timeout the sender **goes back** and resends
  *all* outstanding packets. Per-packet retry limit prevents endless loops.
* *Selective Repeat* (receiver buffering + per-packet ACK/timer) is **not** implemented.

Timing model (deterministic): one loop iteration = 1 tick; one-way delay 1 tick (RTT 2);
loss by "every Nth transmission" pattern and/or seeded LCG percentage.

## 4. BST design
Node = `station_t` + left/right. Iterative (no recursion), ≤ 1024 stations so traversal stacks are
bounded. insert/search/update/delete **O(h)**, traversals **O(n)** time, destroy **O(n)** time / **O(1)** space.
Two-child delete uses the inorder successor. The tree is not self-balancing (worst case h = n).

## 5. Build & run
Requires GCC (C11) and GNU make.
* **Linux:** `sudo apt install build-essential` → `make` → `./build/engine`
* **Windows (MSYS2):** install MSYS2, open the *MinGW64* shell, `pacman -S mingw-w64-x86_64-gcc make`,
  then `make` and `./build/engine.exe`. Run from the project root (the app uses `data/stations.txt`).

| Command | Purpose |
|---|---|
| `make` | build the app (warnings: `-Wall -Wextra -Wpedantic -Wconversion -Wshadow`) |
| `make test` | build + run all three test binaries |
| `make coverage` | gcov line / branch / function coverage |
| `make cppcheck` | Cppcheck (must be installed) |
| `make sanitize` | tests under AddressSanitizer + UBSan (Linux) |
| `make gtest` | GoogleTest suites in `tests/gtest/` (C++ tests calling the C code) |
| `make misra` | Cppcheck + MISRA C:2012 addon → `reports/misra_report.txt` |
| `make valgrind` | Memcheck (leaks, invalid access, uninitialised reads) on all test binaries + the app |
| `make helgrind` | Helgrind data-race check on the multi-threaded gtest cases |
| `make tsan` | ThreadSanitizer alternative to Helgrind |
| `make quality` | runs everything above in one go |

**Tool installation (Ubuntu/Debian):** `sudo apt install build-essential cppcheck valgrind libgtest-dev`
**MSYS2:** `pacman -S mingw-w64-x86_64-gtest mingw-w64-x86_64-cppcheck` (valgrind/helgrind are Linux-only; use WSL).
**MISRA:** the Cppcheck addon needs your own licensed rule-text file: `make misra MISRA_RULES=/path/rules.txt`.

Typical first steps in the menu: `11` (load sample stations) → `7` (simulate, e.g. 500 → 250).
Change loss/window with `8`.

## 6. Sample session (excerpt, default config: window 4, 12 packets, drop every 5th data / 7th ACK)
```
--- Go-Back-N transmission: station 500 -> 250 ---
[t=000] SEND  seq=0  (new)        stn 500->250 | sender window [base=0 next=1]
...
[t=002] SEND  seq=4  (new)        stn 500->250 | sender window [base=4 next=5]
[t=002] LOSS  data seq=4 lost in channel
[t=003] RECV  seq=5  OUT-OF-ORDER discarded (Go-Back-N) | receiver expects seq=4
[t=003] ACK   generated ack=4 (next expected)
[t=007] TIMEOUT oldest unacked seq=4 -> Go-Back-N: resend 4 packet(s)
[t=007] SEND  seq=4  (retransmit) stn 500->250 | sender window [base=4 next=8]
[t=008] RECV  seq=4  accepted, delivered=5 | receiver expects seq=5
[t=051] DONE  all 12 packet(s) delivered in order (stn 500 -> 250)
--- Final status: ALL PACKETS DELIVERED ---
  Data transmissions     : 37 (retransmissions: 25)
  Timeouts               : 7        Simulation ticks : 51
```
Invalid stations: `Validation failed (station 999): not found. Transmission not started.`

## 7. Testing
Two layers: the dependency-free C harness (`tests/*.c`, `make test`) and GoogleTest (`tests/gtest/*.cpp`, `make gtest`:
BST, station/input/storage, Go-Back-N and a multi-threaded suite used for Helgrind/TSan).
`make test` runs 44 test functions / 812 checks (BST 15, station+input+storage+functional 10,
sliding window 19). See `TEST_REPORT.md`. Functional flow (load → validate → transmit → update → delete)
is in `test_sample_data_file_and_functional_flow`. Run from the project root.

## 8. Static analysis / coverage
See `STATIC_ANALYSIS_REPORT.md` and `COVERAGE_REPORT.md`.
*Function coverage* = fraction of functions called at least once; *line coverage* = executed source
lines; *branch coverage* = each conditional outcome (true and false) taken at least once.

## 9. Known limitations
* Go-Back-N only (receiver window fixed at 1; no Selective Repeat).
* Single sender→receiver pair; fixed 1-tick delay; no bandwidth/jitter model.
* BST is unbalanced; capped at 1024 stations. Station names are ASCII only, no `|`.
* Save uses temp file + remove + rename (not atomic on Windows).
* "MISRA C-inspired" - `make misra` is provided, but compliance is only claimed after you run it with a licensed
  rule file and review/deviate every finding (see `STATIC_ANALYSIS_REPORT.md`).
* The engine is single-threaded by design. Helgrind therefore checks the *thread-safety of independent instances*
  (no hidden global state), not shared-state locking.
  (`__typeof__`-free, no recursion, braces everywhere, fixed-width types, no `gets`, bounded I/O.)

## 10. Possible enhancements
Selective Repeat module, AVL/red-black balancing, variable delay/jitter, multi-hop routing over the
station tree, CSV export of statistics, MISRA checker integration.

## 11. Four-week plan
| Week | Deliverables |
|---|---|
| 1 | Requirements, structs, BST + station management, BST tests |
| 2 | Packet/ACK structs, circular queues, Go-Back-N sender/receiver, timeout/retransmit |
| 3 | Menu integration, input validation, file storage, unit + functional tests |
| 4 | Cppcheck, security fixes, coverage ≥ 80 %, optimisation review, docs, demo |

## 12. Requirement traceability (short)
| Requirement | Implementation | Test |
|---|---|---|
| BST add/search/update/delete/inorder/stats | `bst.c` | `test_bst.c` |
| Duplicate ID rejected, empty tree safe | `bst_insert`, `bst_stats` | `test_duplicate_rejected`, `test_stats_and_empty` |
| Free all nodes | `bst_destroy` (called in `main`) | `test_capacity_limit`, `make sanitize` |
| Src/dst validation | `station_validate_endpoints` | `test_endpoint_validation` |
| Window, seq numbers, wrap-around | `sw_sender_*`, `seq_*` | `test_sequence_wraparound_in_simulation` |
| ACK processing (cumulative) | `sw_sender_process_ack` | `test_flow_control_sender_window` |
| Loss / ACK loss / timeout / retransmit | `step_timeout`, `send_data` | `test_packet_loss_recovery`, `test_ack_loss_…` |
| Duplicate detection, ordering | `sw_receiver_on_packet` | `test_receiver_duplicate_and_out_of_order` |
| Retry limit | `sw_sender_mark_retransmit` | `test_max_retransmission_limit` |
| Input validation | `input.c` | `test_parse_u32`, `test_read_line`, `test_prompts` |
| Safe file I/O | `storage.c` | `test_load_rejects_bad_files`, `test_save_errors` |
