# Static Analysis & Dynamic Analysis Report

| Tool | Command | Status in this package |
|---|---|---|
| GCC warnings | `make` (`-Wall -Wextra -Wpedantic -Wconversion -Wshadow`) | **Run: 0 warnings** |
| AddressSanitizer + UBSan | `make sanitize` | **Run: clean** |
| ThreadSanitizer | `make tsan` | **Run: clean** (threaded test, checked with a stand-in test header) |
| Cppcheck | `make cppcheck` | **NOT RUN** - not installed where this package was prepared |
| MISRA C:2012 (Cppcheck addon) | `make misra` | **NOT RUN** - needs cppcheck + your licensed rule-text file |
| Valgrind memcheck | `make valgrind` | **NOT RUN** - not installed (Linux only) |
| Helgrind | `make helgrind` | **NOT RUN** - not installed (Linux only) |
| GoogleTest | `make gtest` | Written and passing (29 tests) against a minimal stand-in; **run once with the real `libgtest`** |

No result is claimed for tools that were not run. Paste real output into this file after running `make quality`.

## How to run
```
sudo apt install build-essential cppcheck valgrind libgtest-dev
make quality          # test, gtest, cppcheck, misra, sanitize, valgrind, helgrind, coverage
```
Reports: `reports/misra_report.txt`. Cppcheck suppressions live in `config/cppcheck_suppressions.txt` (keep minimal, justify each).

## Reading findings
`nullPointer*` possible NULL deref; `memleak`/`resourceLeak` missing free/fclose; `uninitvar` read before write;
`arrayIndexOutOfBounds` bounds bug; `misra-c2012-X.Y` = MISRA rule X.Y (fix, or record a documented deviation).
Valgrind: "definitely lost" / "Invalid read/write" must be 0. Helgrind: "Possible data race" must be 0.
