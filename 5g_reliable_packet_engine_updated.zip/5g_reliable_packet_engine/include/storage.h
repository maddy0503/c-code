/* storage.h - validated text persistence for station records.
 * File format (UTF-8/ASCII text):
 *   line 1 : STATIONS_V1
 *   then   : id|name|distance_km|type      (one station per line)
 *   Blank lines and lines starting with '#' are ignored.
 */
#ifndef STORAGE_H
#define STORAGE_H

#include "bst.h"

#define STORAGE_HEADER "STATIONS_V1"
#define STORAGE_LINE_MAX 128U

/* Writes to "<path>.tmp" first and then replaces <path>. */
status_t storage_save(const bst_t *tree, const char *path);

/* All-or-nothing: *tree is replaced only if the whole file is valid. */
status_t storage_load(bst_t *tree, const char *path);

#endif /* STORAGE_H */
