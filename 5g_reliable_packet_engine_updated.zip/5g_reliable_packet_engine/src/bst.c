/* bst.c - iterative Binary Search Tree keyed by Station ID. */
#include <stdlib.h>
#include "bst.h"

void bst_init(bst_t *tree)
{
    if (tree != NULL) {
        tree->root = NULL;
        tree->count = 0U;
    }
}

status_t bst_insert(bst_t *tree, const station_t *station)
{
    bst_node_t **link;
    bst_node_t *node;
    status_t rc;

    if ((tree == NULL) || (station == NULL)) {
        return STATUS_ERR_NULL;
    }
    rc = station_validate(station);
    if (rc != STATUS_OK) {
        return rc;
    }
    if (tree->count >= BST_MAX_STATIONS) {
        return STATUS_ERR_FULL;
    }
    /* "link" points at the pointer that must receive the new node. */
    link = &tree->root;
    while (*link != NULL) {
        if (station->id == (*link)->data.id) {
            return STATUS_ERR_DUPLICATE;
        }
        link = (station->id < (*link)->data.id) ? &(*link)->left
                                                : &(*link)->right;
    }
    node = (bst_node_t *)malloc(sizeof(*node));
    if (node == NULL) {
        return STATUS_ERR_NOMEM;
    }
    node->data = *station;
    node->left = NULL;
    node->right = NULL;
    *link = node;
    tree->count++;
    return STATUS_OK;
}

const station_t *bst_search(const bst_t *tree, station_id_t id)
{
    const bst_node_t *cur;

    if (tree == NULL) {
        return NULL;
    }
    cur = tree->root;
    while (cur != NULL) {
        if (id == cur->data.id) {
            return &cur->data;
        }
        cur = (id < cur->data.id) ? cur->left : cur->right;
    }
    return NULL;
}

status_t bst_update(bst_t *tree, station_id_t id, const char *name,
                    uint32_t distance_km, const char *type)
{
    station_t updated;
    bst_node_t *cur;
    status_t rc;

    if (tree == NULL) {
        return STATUS_ERR_NULL;
    }
    /* Validate the new values BEFORE touching the stored record. */
    rc = station_init(&updated, id, name, distance_km, type);
    if (rc != STATUS_OK) {
        return rc;
    }
    cur = tree->root;
    while (cur != NULL) {
        if (id == cur->data.id) {
            cur->data = updated;      /* key unchanged -> BST order intact */
            return STATUS_OK;
        }
        cur = (id < cur->data.id) ? cur->left : cur->right;
    }
    return STATUS_ERR_NOT_FOUND;
}

status_t bst_delete(bst_t *tree, station_id_t id)
{
    bst_node_t **link;
    bst_node_t *victim;

    if (tree == NULL) {
        return STATUS_ERR_NULL;
    }
    link = &tree->root;
    while ((*link != NULL) && ((*link)->data.id != id)) {
        link = (id < (*link)->data.id) ? &(*link)->left : &(*link)->right;
    }
    if (*link == NULL) {
        return STATUS_ERR_NOT_FOUND;
    }
    victim = *link;
    if (victim->left == NULL) {                 /* leaf or only right child */
        *link = victim->right;
    } else if (victim->right == NULL) {         /* only left child */
        *link = victim->left;
    } else {                                    /* two children */
        bst_node_t **succ_link = &victim->right;
        bst_node_t *succ;
        while ((*succ_link)->left != NULL) {    /* inorder successor */
            succ_link = &(*succ_link)->left;
        }
        succ = *succ_link;
        *succ_link = succ->right;               /* detach successor */
        succ->left = victim->left;
        succ->right = victim->right;
        *link = succ;                           /* splice into victim's place */
    }
    free(victim);
    victim = NULL;
    tree->count--;
    return STATUS_OK;
}

status_t bst_inorder(const bst_t *tree, bst_visit_fn visit, void *context)
{
    const bst_node_t *stack[BST_MAX_STATIONS];
    size_t sp = 0U;
    const bst_node_t *cur;

    if ((tree == NULL) || (visit == NULL)) {
        return STATUS_ERR_NULL;
    }
    cur = tree->root;
    while ((cur != NULL) || (sp > 0U)) {
        while (cur != NULL) {
            if (sp >= BST_MAX_STATIONS) {
                return STATUS_ERR_STATE;
            }
            stack[sp] = cur;
            sp++;
            cur = cur->left;
        }
        sp--;
        cur = stack[sp];
        visit(&cur->data, context);
        cur = cur->right;
    }
    return STATUS_OK;
}

status_t bst_preorder(const bst_t *tree, bst_visit_fn visit, void *context)
{
    const bst_node_t *stack[BST_MAX_STATIONS];
    size_t sp = 0U;
    const bst_node_t *cur;

    if ((tree == NULL) || (visit == NULL)) {
        return STATUS_ERR_NULL;
    }
    if (tree->root != NULL) {
        stack[0] = tree->root;
        sp = 1U;
    }
    while (sp > 0U) {
        sp--;
        cur = stack[sp];
        visit(&cur->data, context);
        if (sp + 2U > BST_MAX_STATIONS) {
            return STATUS_ERR_STATE;
        }
        if (cur->right != NULL) { stack[sp] = cur->right; sp++; }
        if (cur->left != NULL)  { stack[sp] = cur->left;  sp++; }
    }
    return STATUS_OK;
}

status_t bst_stats(const bst_t *tree, uint32_t *count, station_id_t *min_id,
                   station_id_t *max_id)
{
    const bst_node_t *cur;

    if ((tree == NULL) || (count == NULL) || (min_id == NULL) || (max_id == NULL)) {
        return STATUS_ERR_NULL;
    }
    *count = tree->count;
    if (tree->root == NULL) {
        *min_id = 0U;
        *max_id = 0U;
        return STATUS_ERR_EMPTY;
    }
    cur = tree->root;
    while (cur->left != NULL)  { cur = cur->left; }
    *min_id = cur->data.id;
    cur = tree->root;
    while (cur->right != NULL) { cur = cur->right; }
    *max_id = cur->data.id;
    return STATUS_OK;
}

void bst_destroy(bst_t *tree)
{
    bst_node_t *cur;

    if (tree == NULL) {
        return;
    }
    /* Constant-space teardown: rotate left children up, then free the root. */
    cur = tree->root;
    while (cur != NULL) {
        if (cur->left != NULL) {
            bst_node_t *l = cur->left;
            cur->left = l->right;
            l->right = cur;
            cur = l;
        } else {
            bst_node_t *next = cur->right;
            free(cur);
            cur = next;
        }
    }
    tree->root = NULL;
    tree->count = 0U;
}
