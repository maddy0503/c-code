/* input.c - bounded console input and strict numeric parsing. */
#include <string.h>
#include "input.h"

status_t input_read_line(FILE *in, char *buffer, size_t capacity)
{
    size_t len = 0U;
    int c;

    if ((in == NULL) || (buffer == NULL) || (capacity < 2U) || (capacity > 4096U)) {
        return STATUS_ERR_NULL;
    }
    if (fgets(buffer, (int)capacity, in) == NULL) {
        buffer[0] = '\0';
        return STATUS_ERR_IO;
    }
    while ((len < capacity) && (buffer[len] != '\0')) {
        len++;
    }
    if ((len > 0U) && (buffer[len - 1U] == '\n')) {
        buffer[len - 1U] = '\0';
        if ((len > 1U) && (buffer[len - 2U] == '\r')) {
            buffer[len - 2U] = '\0';
        }
        return STATUS_OK;
    }
    if (len == (capacity - 1U)) {
        /* Buffer full without newline: exact fit, EOF, or an over-long line. */
        c = fgetc(in);
        if ((c == '\n') || (c == EOF)) {
            return STATUS_OK;
        }
        while ((c != '\n') && (c != EOF)) {
            c = fgetc(in);
        }
        return STATUS_ERR_RANGE;
    }
    return STATUS_OK;                  /* last line without trailing newline */
}

status_t input_parse_u32(const char *text, uint32_t min, uint32_t max,
                         uint32_t *value)
{
    size_t start = 0U;
    size_t end;
    uint64_t acc = 0U;
    size_t i;

    if ((text == NULL) || (value == NULL)) {
        return STATUS_ERR_NULL;
    }
    end = strlen(text);
    while ((start < end) && ((text[start] == ' ') || (text[start] == '\t'))) {
        start++;
    }
    while ((end > start) && ((text[end - 1U] == ' ') || (text[end - 1U] == '\t'))) {
        end--;
    }
    if (start == end) {
        return STATUS_ERR_FORMAT;      /* empty input */
    }
    for (i = start; i < end; i++) {
        if ((text[i] < '0') || (text[i] > '9')) {
            return STATUS_ERR_FORMAT;  /* sign, letter, trailing junk ... */
        }
        acc = (acc * 10U) + (uint64_t)(text[i] - '0');
        if (acc > (uint64_t)UINT32_MAX) {
            return STATUS_ERR_RANGE;   /* overflow guard */
        }
    }
    if ((acc < (uint64_t)min) || (acc > (uint64_t)max)) {
        return STATUS_ERR_RANGE;
    }
    *value = (uint32_t)acc;
    return STATUS_OK;
}

status_t input_prompt_u32(FILE *in, FILE *out, const char *prompt,
                          uint32_t min, uint32_t max, uint32_t *value)
{
    char line[64];
    uint32_t attempt;

    if ((in == NULL) || (out == NULL) || (prompt == NULL) || (value == NULL)) {
        return STATUS_ERR_NULL;
    }
    for (attempt = 0U; attempt < INPUT_MAX_ATTEMPTS; attempt++) {
        status_t rc;
        (void)fprintf(out, "%s [%u-%u]: ", prompt, (unsigned)min, (unsigned)max);
        rc = input_read_line(in, line, sizeof(line));
        if (rc == STATUS_ERR_IO) {
            return STATUS_ERR_IO;
        }
        if (rc == STATUS_OK) {
            rc = input_parse_u32(line, min, max, value);
            if (rc == STATUS_OK) {
                return STATUS_OK;
            }
        }
        (void)fprintf(out, "  Invalid input (%s). Enter digits only, within range.\n",
                      status_to_string(rc));
    }
    return STATUS_ERR_RANGE;
}

status_t input_prompt_text(FILE *in, FILE *out, const char *prompt,
                           char *buffer, size_t capacity,
                           input_text_validator_fn validator)
{
    uint32_t attempt;

    if ((in == NULL) || (out == NULL) || (prompt == NULL) || (buffer == NULL) ||
        (validator == NULL)) {
        return STATUS_ERR_NULL;
    }
    for (attempt = 0U; attempt < INPUT_MAX_ATTEMPTS; attempt++) {
        status_t rc;
        (void)fprintf(out, "%s: ", prompt);
        rc = input_read_line(in, buffer, capacity);
        if (rc == STATUS_ERR_IO) {
            return STATUS_ERR_IO;
        }
        if (rc == STATUS_OK) {
            rc = validator(buffer);
            if (rc == STATUS_OK) {
                return STATUS_OK;
            }
        }
        (void)fprintf(out, "  Invalid text (%s). Allowed: letters, digits, space, - _ .\n",
                      status_to_string(rc));
    }
    return STATUS_ERR_RANGE;
}
