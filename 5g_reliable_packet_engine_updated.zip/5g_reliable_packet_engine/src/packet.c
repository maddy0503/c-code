/* packet.c - packet construction, sequence arithmetic, channel queues. */
#include <string.h>
#include "packet.h"

status_t packet_init(packet_t *packet, uint8_t seq, station_id_t src,
                     station_id_t dst, const uint8_t *payload, size_t length)
{
    if (packet == NULL) {
        return STATUS_ERR_NULL;
    }
    if ((length > 0U) && (payload == NULL)) {
        return STATUS_ERR_NULL;
    }
    if ((seq >= SEQ_MODULUS) || (length > PAYLOAD_MAX)) {
        return STATUS_ERR_RANGE;      /* checked BEFORE any copy */
    }
    if ((station_validate_id(src) != STATUS_OK) ||
        (station_validate_id(dst) != STATUS_OK)) {
        return STATUS_ERR_RANGE;
    }
    (void)memset(packet, 0, sizeof(*packet));
    packet->seq = seq;
    packet->src = src;
    packet->dst = dst;
    packet->payload_len = (uint8_t)length;
    if (length > 0U) {
        (void)memcpy(packet->payload, payload, length);
    }
    packet->status = PKT_STATUS_EMPTY;
    return STATUS_OK;
}

uint8_t seq_distance(uint8_t from, uint8_t to)
{
    return (uint8_t)(((uint32_t)to + SEQ_MODULUS - (uint32_t)from) % SEQ_MODULUS);
}

uint8_t seq_next(uint8_t seq)
{
    return (uint8_t)(((uint32_t)seq + 1U) % SEQ_MODULUS);
}

void pktq_init(pkt_queue_t *queue)
{
    if (queue != NULL) {
        queue->head = 0U;
        queue->count = 0U;
    }
}

status_t pktq_push(pkt_queue_t *queue, const packet_t *packet, uint32_t due_tick)
{
    size_t tail;

    if ((queue == NULL) || (packet == NULL)) {
        return STATUS_ERR_NULL;
    }
    if (queue->count >= CHANNEL_CAP) {
        return STATUS_ERR_FULL;
    }
    tail = (queue->head + queue->count) % CHANNEL_CAP;
    queue->slots[tail].pkt = *packet;
    queue->slots[tail].due_tick = due_tick;
    queue->count++;
    return STATUS_OK;
}

bool pktq_pop_due(pkt_queue_t *queue, uint32_t now, packet_t *out)
{
    if ((queue == NULL) || (out == NULL) || (queue->count == 0U)) {
        return false;
    }
    if (queue->slots[queue->head].due_tick > now) {
        return false;
    }
    *out = queue->slots[queue->head].pkt;
    queue->head = (queue->head + 1U) % CHANNEL_CAP;
    queue->count--;
    return true;
}

void ackq_init(ack_queue_t *queue)
{
    if (queue != NULL) {
        queue->head = 0U;
        queue->count = 0U;
    }
}

status_t ackq_push(ack_queue_t *queue, const ack_t *ack, uint32_t due_tick)
{
    size_t tail;

    if ((queue == NULL) || (ack == NULL)) {
        return STATUS_ERR_NULL;
    }
    if (queue->count >= CHANNEL_CAP) {
        return STATUS_ERR_FULL;
    }
    tail = (queue->head + queue->count) % CHANNEL_CAP;
    queue->slots[tail].ack = *ack;
    queue->slots[tail].due_tick = due_tick;
    queue->count++;
    return STATUS_OK;
}

bool ackq_pop_due(ack_queue_t *queue, uint32_t now, ack_t *out)
{
    if ((queue == NULL) || (out == NULL) || (queue->count == 0U)) {
        return false;
    }
    if (queue->slots[queue->head].due_tick > now) {
        return false;
    }
    *out = queue->slots[queue->head].ack;
    queue->head = (queue->head + 1U) % CHANNEL_CAP;
    queue->count--;
    return true;
}
