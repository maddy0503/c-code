/* station.c - station record validation and printing. */
#include <stdio.h>
#include <string.h>
#include "station.h"
#include "bst.h"

static bool is_allowed_char(char c)
{
    return ((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z')) ||
           ((c >= '0') && (c <= '9')) || (c == ' ') || (c == '-') ||
           (c == '_') || (c == '.');
}

status_t station_validate_text(const char *text, size_t buffer_size)
{
    size_t i = 0U;
    bool terminated = false;

    if ((text == NULL) || (buffer_size < 2U)) {
        return STATUS_ERR_NULL;
    }
    /* Bounded scan: never reads at or beyond buffer_size bytes. */
    while (i < buffer_size) {
        if (text[i] == '\0') {
            terminated = true;
            break;
        }
        if (!is_allowed_char(text[i])) {
            return STATUS_ERR_FORMAT;
        }
        i++;
    }
    if (!terminated) {
        return STATUS_ERR_RANGE;       /* too long for the destination */
    }
    if (i == 0U) {
        return STATUS_ERR_FORMAT;      /* empty */
    }
    if ((text[0] == ' ') || (text[i - 1U] == ' ')) {
        return STATUS_ERR_FORMAT;      /* leading/trailing blank */
    }
    return STATUS_OK;
}

status_t station_validate_id(station_id_t id)
{
    return ((id >= STATION_ID_MIN) && (id <= STATION_ID_MAX)) ? STATUS_OK
                                                              : STATUS_ERR_RANGE;
}

status_t station_validate(const station_t *station)
{
    status_t rc;

    if (station == NULL) {
        return STATUS_ERR_NULL;
    }
    rc = station_validate_id(station->id);
    if (rc == STATUS_OK) {
        rc = station_validate_text(station->name, STATION_NAME_MAX);
    }
    if ((rc == STATUS_OK) && (station->distance_km > STATION_DISTANCE_MAX)) {
        rc = STATUS_ERR_RANGE;
    }
    if (rc == STATUS_OK) {
        rc = station_validate_text(station->type, STATION_TYPE_MAX);
    }
    return rc;
}

status_t station_init(station_t *station, station_id_t id, const char *name,
                      uint32_t distance_km, const char *type)
{
    status_t rc;
    size_t name_len;
    size_t type_len;

    if (station == NULL) {
        return STATUS_ERR_NULL;
    }
    rc = station_validate_id(id);
    if (rc == STATUS_OK) {
        rc = station_validate_text(name, STATION_NAME_MAX);
    }
    if ((rc == STATUS_OK) && (distance_km > STATION_DISTANCE_MAX)) {
        rc = STATUS_ERR_RANGE;
    }
    if (rc == STATUS_OK) {
        rc = station_validate_text(type, STATION_TYPE_MAX);
    }
    if (rc != STATUS_OK) {
        return rc;
    }
    /* Both strings are validated to be NUL-terminated inside their buffers. */
    name_len = strlen(name);
    type_len = strlen(type);
    (void)memset(station, 0, sizeof(*station));
    station->id = id;
    station->distance_km = distance_km;
    (void)memcpy(station->name, name, name_len + 1U);
    (void)memcpy(station->type, type, type_len + 1U);
    return STATUS_OK;
}

status_t station_validate_endpoints(const struct bst *tree, station_id_t src,
                                    station_id_t dst, station_id_t *bad_id)
{
    if (bad_id != NULL) {
        *bad_id = 0U;
    }
    if (tree == NULL) {
        return STATUS_ERR_NULL;
    }
    if (station_validate_id(src) != STATUS_OK) {
        if (bad_id != NULL) { *bad_id = src; }
        return STATUS_ERR_RANGE;
    }
    if (station_validate_id(dst) != STATUS_OK) {
        if (bad_id != NULL) { *bad_id = dst; }
        return STATUS_ERR_RANGE;
    }
    if (src == dst) {
        if (bad_id != NULL) { *bad_id = src; }
        return STATUS_ERR_SAME_ENDPOINT;
    }
    if (bst_search(tree, src) == NULL) {
        if (bad_id != NULL) { *bad_id = src; }
        return STATUS_ERR_NOT_FOUND;
    }
    if (bst_search(tree, dst) == NULL) {
        if (bad_id != NULL) { *bad_id = dst; }
        return STATUS_ERR_NOT_FOUND;
    }
    return STATUS_OK;
}

void station_print(const station_t *station)
{
    if (station == NULL) {
        return;
    }
    (void)printf("  %-6u %-31s %7u km  %s\n", (unsigned)station->id,
                 station->name, (unsigned)station->distance_km, station->type);
}
