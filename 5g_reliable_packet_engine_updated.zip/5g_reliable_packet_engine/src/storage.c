/* storage.c - safe save/load of station records. */
#include <stdio.h>
#include <string.h>
#include "storage.h"
#include "input.h"

typedef struct {
    FILE    *file;
    status_t status;
} save_ctx_t;

static void save_visitor(const station_t *s, void *context)
{
    save_ctx_t *ctx = (save_ctx_t *)context;

    if (ctx->status != STATUS_OK) {
        return;
    }
    if (fprintf(ctx->file, "%u|%s|%u|%s\n", (unsigned)s->id, s->name,
                (unsigned)s->distance_km, s->type) < 0) {
        ctx->status = STATUS_ERR_IO;
    }
}

status_t storage_save(const bst_t *tree, const char *path)
{
    char tmp_path[256];
    save_ctx_t ctx;
    size_t len;
    status_t rc;

    if ((tree == NULL) || (path == NULL)) {
        return STATUS_ERR_NULL;
    }
    len = strlen(path);
    if ((len == 0U) || (len > (sizeof(tmp_path) - 5U))) {
        return STATUS_ERR_RANGE;
    }
    (void)memcpy(tmp_path, path, len);
    (void)memcpy(&tmp_path[len], ".tmp", 5U);   /* includes NUL */

    ctx.file = fopen(tmp_path, "w");
    if (ctx.file == NULL) {
        return STATUS_ERR_IO;
    }
    ctx.status = STATUS_OK;
    if (fprintf(ctx.file, "%s\n", STORAGE_HEADER) < 0) {
        ctx.status = STATUS_ERR_IO;
    }
    /* Preorder keeps the tree shape when the file is loaded again. */
    rc = bst_preorder(tree, save_visitor, &ctx);
    if (rc == STATUS_OK) {
        rc = ctx.status;
    }
    if (fclose(ctx.file) != 0) {
        rc = STATUS_ERR_IO;
    }
    if (rc != STATUS_OK) {
        (void)remove(tmp_path);
        return rc;
    }
    /* rename() will not overwrite on Windows, so remove the old file first. */
    (void)remove(path);
    if (rename(tmp_path, path) != 0) {
        return STATUS_ERR_IO;
    }
    return STATUS_OK;
}

/* Splits "a|b|c|d" in place into 4 fields. Exactly 3 separators required. */
static status_t split_fields(char *line, char *fields[4])
{
    size_t idx = 0U;
    char *p = line;

    fields[0] = line;
    while (*p != '\0') {
        if (*p == '|') {
            *p = '\0';
            idx++;
            if (idx > 3U) {
                return STATUS_ERR_FORMAT;
            }
            fields[idx] = p + 1;
        }
        p++;
    }
    return (idx == 3U) ? STATUS_OK : STATUS_ERR_FORMAT;
}

static status_t parse_record(char *line, station_t *out)
{
    char *f[4];
    uint32_t id = 0U;
    uint32_t dist = 0U;
    status_t rc;

    rc = split_fields(line, f);
    if (rc != STATUS_OK) {
        return rc;
    }
    if ((input_parse_u32(f[0], STATION_ID_MIN, STATION_ID_MAX, &id) != STATUS_OK) ||
        (input_parse_u32(f[2], 0U, STATION_DISTANCE_MAX, &dist) != STATUS_OK)) {
        return STATUS_ERR_FORMAT;
    }
    return station_init(out, id, f[1], dist, f[3]);
}

status_t storage_load(bst_t *tree, const char *path)
{
    FILE *file;
    char line[STORAGE_LINE_MAX];
    bst_t loaded;
    station_t st;
    status_t rc = STATUS_OK;
    bool header_seen = false;
    size_t len;

    if ((tree == NULL) || (path == NULL)) {
        return STATUS_ERR_NULL;
    }
    file = fopen(path, "r");
    if (file == NULL) {
        return STATUS_ERR_IO;
    }
    bst_init(&loaded);
    while ((rc == STATUS_OK) && (fgets(line, (int)sizeof(line), file) != NULL)) {
        len = strlen(line);
        if ((len > 0U) && (line[len - 1U] == '\n')) {
            line[len - 1U] = '\0';
            len--;
        } else if (len == (sizeof(line) - 1U)) {
            rc = STATUS_ERR_FORMAT;        /* line longer than the buffer */
            break;
        } else {
            /* final line without newline: fine */
        }
        if ((len > 0U) && (line[len - 1U] == '\r')) {
            line[len - 1U] = '\0';
            len--;
        }
        if ((len == 0U) || (line[0] == '#')) {
            continue;                      /* blank line or comment */
        }
        if (!header_seen) {
            rc = (strcmp(line, STORAGE_HEADER) == 0) ? STATUS_OK : STATUS_ERR_FORMAT;
            header_seen = true;
            continue;
        }
        rc = parse_record(line, &st);
        if (rc == STATUS_OK) {
            rc = bst_insert(&loaded, &st);   /* rejects duplicates / overflow */
        }
    }
    if ((rc == STATUS_OK) && (ferror(file) != 0)) {
        rc = STATUS_ERR_IO;
    }
    if ((rc == STATUS_OK) && (!header_seen)) {
        rc = STATUS_ERR_FORMAT;            /* empty or header-less file */
    }
    (void)fclose(file);
    if (rc != STATUS_OK) {
        bst_destroy(&loaded);              /* all-or-nothing */
        return rc;
    }
    bst_destroy(tree);
    *tree = loaded;
    return STATUS_OK;
}
