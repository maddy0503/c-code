// GoogleTest unit tests for station validation, input parsing and storage.
#include <gtest/gtest.h>
#include <cstdio>
#include <string>

extern "C" {
#include "bst.h"
#include "input.h"
#include "station.h"
#include "storage.h"
}

namespace {

TEST(StationValidation, AcceptsGoodRecord)
{
    station_t s;
    EXPECT_EQ(STATUS_OK, station_init(&s, 500U, "Central Hub", 0U, "Core"));
    EXPECT_STREQ("Central Hub", s.name);
}

TEST(StationValidation, RejectsBadFields)
{
    station_t s;
    EXPECT_EQ(STATUS_ERR_RANGE, station_init(&s, 0U, "A", 1U, "B"));
    EXPECT_EQ(STATUS_ERR_RANGE, station_init(&s, STATION_ID_MAX + 1U, "A", 1U, "B"));
    EXPECT_NE(STATUS_OK, station_init(&s, 1U, "bad|name", 1U, "B"));
    EXPECT_NE(STATUS_OK, station_init(&s, 1U, " leading", 1U, "B"));
    EXPECT_NE(STATUS_OK, station_init(&s, 1U, "", 1U, "B"));
    EXPECT_NE(STATUS_OK, station_init(&s, 1U, "A", STATION_DISTANCE_MAX + 1U, "B"));
    EXPECT_NE(STATUS_OK, station_init(&s, 1U, std::string(40, 'x').c_str(), 1U, "B"));
}

TEST(StationEndpoints, ValidatesSourceAndDestination)
{
    bst_t tree;
    bst_init(&tree);
    station_t a, b;
    ASSERT_EQ(STATUS_OK, station_init(&a, 1U, "A", 1U, "Core"));
    ASSERT_EQ(STATUS_OK, station_init(&b, 2U, "B", 2U, "Core"));
    ASSERT_EQ(STATUS_OK, bst_insert(&tree, &a));
    ASSERT_EQ(STATUS_OK, bst_insert(&tree, &b));

    station_id_t bad = 77U;
    EXPECT_EQ(STATUS_OK, station_validate_endpoints(&tree, 1U, 2U, &bad));
    EXPECT_EQ(0U, bad);
    EXPECT_EQ(STATUS_ERR_SAME_ENDPOINT, station_validate_endpoints(&tree, 1U, 1U, &bad));
    EXPECT_EQ(STATUS_ERR_NOT_FOUND, station_validate_endpoints(&tree, 1U, 999U, &bad));
    EXPECT_EQ(999U, bad);
    bst_destroy(&tree);
}

TEST(InputParsing, ParseU32)
{
    uint32_t v = 0U;
    EXPECT_EQ(STATUS_OK, input_parse_u32("42", 0U, 100U, &v));
    EXPECT_EQ(42U, v);
    EXPECT_NE(STATUS_OK, input_parse_u32("", 0U, 100U, &v));
    EXPECT_NE(STATUS_OK, input_parse_u32("-5", 0U, 100U, &v));
    EXPECT_NE(STATUS_OK, input_parse_u32("abc", 0U, 100U, &v));
    EXPECT_NE(STATUS_OK, input_parse_u32("12abc", 0U, 100U, &v));
    EXPECT_NE(STATUS_OK, input_parse_u32("101", 0U, 100U, &v));
    EXPECT_NE(STATUS_OK, input_parse_u32("99999999999999", 0U, 100U, &v));
}

TEST(InputParsing, ReadLineHandlesLongInputAndEof)
{
    FILE *f = std::tmpfile();
    ASSERT_NE(nullptr, f);
    std::fputs("short\n", f);
    std::fputs("this line is much longer than the buffer\n", f);
    std::rewind(f);
    char buf[8];
    EXPECT_EQ(STATUS_OK, input_read_line(f, buf, sizeof buf));
    EXPECT_STREQ("short", buf);
    EXPECT_EQ(STATUS_ERR_RANGE, input_read_line(f, buf, sizeof buf));
    EXPECT_EQ(STATUS_ERR_IO, input_read_line(f, buf, sizeof buf));
    std::fclose(f);
}

class StorageTest : public ::testing::Test {
protected:
    void SetUp() override { bst_init(&tree_); path_ = "gtest_storage.tmp.txt"; }
    void TearDown() override
    {
        bst_destroy(&tree_);
        std::remove(path_.c_str());
        std::remove((path_ + ".tmp").c_str());
    }
    bst_t tree_;
    std::string path_;
};

TEST_F(StorageTest, SaveLoadRoundTrip)
{
    station_t s;
    for (station_id_t id : {30U, 10U, 20U}) {
        ASSERT_EQ(STATUS_OK, station_init(&s, id, "Node", id, "Relay"));
        ASSERT_EQ(STATUS_OK, bst_insert(&tree_, &s));
    }
    ASSERT_EQ(STATUS_OK, storage_save(&tree_, path_.c_str()));

    bst_t loaded;
    bst_init(&loaded);
    ASSERT_EQ(STATUS_OK, storage_load(&loaded, path_.c_str()));
    EXPECT_EQ(3U, loaded.count);
    ASSERT_NE(nullptr, bst_search(&loaded, 20U));
    EXPECT_EQ(20U, bst_search(&loaded, 20U)->distance_km);
    bst_destroy(&loaded);
}

TEST_F(StorageTest, CorruptFileLeavesTreeUntouched)
{
    station_t s;
    ASSERT_EQ(STATUS_OK, station_init(&s, 5U, "Keep", 1U, "Core"));
    ASSERT_EQ(STATUS_OK, bst_insert(&tree_, &s));

    FILE *f = std::fopen(path_.c_str(), "w");
    ASSERT_NE(nullptr, f);
    std::fputs("WRONG_HEADER\n1|A|1|B\n", f);
    std::fclose(f);

    EXPECT_NE(STATUS_OK, storage_load(&tree_, path_.c_str()));
    EXPECT_EQ(1U, tree_.count);
    EXPECT_NE(nullptr, bst_search(&tree_, 5U));
    EXPECT_NE(STATUS_OK, storage_load(&tree_, "does_not_exist.txt"));
}

}  // namespace
