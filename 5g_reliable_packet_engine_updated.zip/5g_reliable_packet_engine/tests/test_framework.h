/* test_framework.h - tiny dependency-free test harness (single TU per binary). */
#ifndef TEST_FRAMEWORK_H
#define TEST_FRAMEWORK_H

#include <stdio.h>

static int g_checks = 0;
static int g_failed = 0;

#define CHECK(cond)                                                          \
    do {                                                                     \
        g_checks++;                                                          \
        if (!(cond)) {                                                       \
            g_failed++;                                                      \
            (void)printf("    FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); \
        }                                                                    \
    } while (0)

#define RUN_TEST(fn)                                                         \
    do {                                                                     \
        int before_ = g_failed;                                              \
        fn();                                                                \
        (void)printf("[%s] %s\n", (g_failed == before_) ? "PASS" : "FAIL", #fn); \
    } while (0)

#define TEST_SUMMARY()                                                       \
    ((void)printf("%d checks, %d failed\n", g_checks, g_failed),             \
     (g_failed == 0) ? 0 : 1)

#endif
